"""
models.py
---------
Model training, hyperparameter tuning, and evaluation for the
Sierra Leone Agricultural ML project.

Author: Ibrahim Denis Fofanah
Affiliation: Pace University / RiseAfrica Foundation for STEM and Innovation
"""

import numpy as np
import pandas as pd
import joblib
import os
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.model_selection import cross_val_score, GridSearchCV, KFold
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
from xgboost import XGBRegressor


# ── Model Configurations ──────────────────────────────────────────────────────

RF_PARAMS = {
    'n_estimators': 200,
    'max_depth': 6,
    'min_samples_split': 3,
    'min_samples_leaf': 2,
    'random_state': 42,
    'n_jobs': -1
}

XGB_PARAMS = {
    'n_estimators': 200,
    'max_depth': 4,
    'learning_rate': 0.05,
    'subsample': 0.8,
    'colsample_bytree': 0.8,
    'random_state': 42,
    'verbosity': 0
}

GBM_PARAMS = {
    'n_estimators': 200,
    'max_depth': 4,
    'learning_rate': 0.05,
    'subsample': 0.8,
    'random_state': 42
}


def prepare_features(df: pd.DataFrame,
                     target_col: str,
                     drop_cols: list = None) -> tuple:
    """
    Prepare feature matrix X and target vector y.

    Parameters
    ----------
    df : pd.DataFrame
        Analysis dataset.
    target_col : str
        Name of the target column (e.g. 'Rice_Yield').
    drop_cols : list
        Additional columns to drop from features.

    Returns
    -------
    tuple : (X, y, feature_names)
    """
    drop = ['Year'] + (drop_cols or [])

    # Drop target and non-feature columns
    X = df.drop(columns=[target_col] + [c for c in drop if c in df.columns])

    # Keep only numeric columns
    X = X.select_dtypes(include=[np.number])

    # Drop rows where target is NaN
    mask = df[target_col].notna()
    X = X[mask].copy()
    y = df.loc[mask, target_col].copy()

    # Fill remaining NaN in features with column median
    X = X.fillna(X.median())

    feature_names = X.columns.tolist()
    print(f"[✓] Features: {len(feature_names)} | Samples: {len(y)}")
    print(f"    Target: {target_col} | Range: {y.min():.1f} – {y.max():.1f}")
    return X.values, y.values, feature_names


def train_all_models(X_train: np.ndarray,
                     y_train: np.ndarray) -> dict:
    """
    Train Random Forest, XGBoost, and GBM models.

    Parameters
    ----------
    X_train : np.ndarray
        Training features.
    y_train : np.ndarray
        Training targets.

    Returns
    -------
    dict
        Dictionary of trained models: {'RF': model, 'XGBoost': model, 'GBM': model}
    """
    models = {}

    print("\n[→] Training Random Forest...")
    rf = RandomForestRegressor(**RF_PARAMS)
    rf.fit(X_train, y_train)
    models['Random Forest'] = rf
    print("    [✓] Random Forest trained")

    print("[→] Training XGBoost...")
    xgb = XGBRegressor(**XGB_PARAMS)
    xgb.fit(X_train, y_train)
    models['XGBoost'] = xgb
    print("    [✓] XGBoost trained")

    print("[→] Training Gradient Boosting...")
    gbm = GradientBoostingRegressor(**GBM_PARAMS)
    gbm.fit(X_train, y_train)
    models['GBM'] = gbm
    print("    [✓] GBM trained")

    return models


def evaluate_models(models: dict,
                    X_test: np.ndarray,
                    y_test: np.ndarray) -> pd.DataFrame:
    """
    Evaluate all models and return a comparison table.

    Parameters
    ----------
    models : dict
        Dictionary of trained models.
    X_test : np.ndarray
        Test features.
    y_test : np.ndarray
        Test targets.

    Returns
    -------
    pd.DataFrame
        Model comparison table with R², RMSE, MAE.
    """
    results = []

    for name, model in models.items():
        y_pred = model.predict(X_test)

        r2   = r2_score(y_test, y_pred)
        rmse = np.sqrt(mean_squared_error(y_test, y_pred))
        mae  = mean_absolute_error(y_test, y_pred)

        results.append({
            'Model': name,
            'R²': round(r2, 4),
            'RMSE': round(rmse, 2),
            'MAE': round(mae, 2),
        })

        print(f"  {name:20s} | R²: {r2:.4f} | RMSE: {rmse:.2f} | MAE: {mae:.2f}")

    results_df = pd.DataFrame(results).sort_values('R²', ascending=False)
    return results_df


def cross_validate_models(models: dict,
                          X: np.ndarray,
                          y: np.ndarray,
                          cv: int = 5) -> pd.DataFrame:
    """
    Run k-fold cross-validation for all models.

    Parameters
    ----------
    models : dict
        Dictionary of trained models.
    X : np.ndarray
        Full feature matrix.
    y : np.ndarray
        Full target vector.
    cv : int
        Number of folds (default: 5).

    Returns
    -------
    pd.DataFrame
        Cross-validation results.
    """
    kf = KFold(n_splits=cv, shuffle=True, random_state=42)
    cv_results = []

    print(f"\n[→] {cv}-Fold Cross-Validation:")
    for name, model in models.items():
        scores = cross_val_score(model, X, y, cv=kf, scoring='r2')
        cv_results.append({
            'Model': name,
            'CV_R²_Mean': round(scores.mean(), 4),
            'CV_R²_Std': round(scores.std(), 4),
            'CV_R²_Min': round(scores.min(), 4),
            'CV_R²_Max': round(scores.max(), 4),
        })
        print(f"  {name:20s} | Mean R²: {scores.mean():.4f} ± {scores.std():.4f}")

    return pd.DataFrame(cv_results).sort_values('CV_R²_Mean', ascending=False)


def get_feature_importance(model,
                           feature_names: list,
                           model_name: str = '') -> pd.DataFrame:
    """
    Extract and rank feature importances from a trained model.

    Parameters
    ----------
    model : fitted sklearn/xgb model
        Trained model with feature_importances_ attribute.
    feature_names : list
        List of feature names.
    model_name : str
        Name label for the model.

    Returns
    -------
    pd.DataFrame
        Ranked feature importances.
    """
    importances = model.feature_importances_
    fi_df = pd.DataFrame({
        'Feature': feature_names,
        'Importance': importances,
        'Model': model_name
    }).sort_values('Importance', ascending=False).reset_index(drop=True)

    fi_df['Importance_Pct'] = (fi_df['Importance'] / fi_df['Importance'].sum() * 100).round(2)
    return fi_df


def save_model(model, model_name: str, output_dir: str) -> None:
    """
    Save a trained model to disk.

    Parameters
    ----------
    model : fitted model
        Trained sklearn/xgb model.
    model_name : str
        Name for the saved file.
    output_dir : str
        Directory to save model.
    """
    os.makedirs(output_dir, exist_ok=True)
    filepath = os.path.join(output_dir, f"{model_name.replace(' ', '_')}.pkl")
    joblib.dump(model, filepath)
    print(f"[✓] Model saved: {filepath}")


def load_model(filepath: str):
    """Load a saved model from disk."""
    model = joblib.load(filepath)
    print(f"[✓] Model loaded: {filepath}")
    return model
